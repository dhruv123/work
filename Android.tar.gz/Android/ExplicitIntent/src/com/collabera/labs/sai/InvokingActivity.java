package com.collabera.labs.sai;


public class InvokingActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        Button invokingButton = (Button)findViewById(R.id.invokebutton);
        invokingButton.setOnClickListener(new OnClickListener() {
        	
        	public <Intent> void onClick(View v) {
        		Intent explicitIntent = new Intent(InvokingActivity.this,InvokedActivity.class);
        		startActivity(explicitIntent);
        	}
        });
    }
}