package com.zaptech.impicitintent;

import android.os.Bundle;
import android.provider.Contacts.People;
import android.provider.ContactsContract;


import android.app.Activity;

import android.content.Intent;


import android.view.View;


@SuppressWarnings("deprecation")
public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	
	}
	
public void conmethod(View v) {
            		Intent contacts = new Intent();
            		contacts.setAction(android.content.Intent.ACTION_VIEW);
            		contacts.setData(ContactsContract.Contacts.CONTENT_URI);
            		startActivity(contacts);
            	}
            

}