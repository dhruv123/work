package com.example.navigateactivity;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity3 extends Activity {
	
	
	

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity3_main);
    }
    
    public void redmethod(View v)
    {
    	TextView t =(TextView) findViewById(R.id.textView1);
    	t.setTextColor(Color.parseColor("#FF0000 "));
    	
    }
    public void greenmethod(View v)
    {
    	TextView t =(TextView) findViewById(R.id.textView1);
    	t.setTextColor(Color.parseColor("#FF0000 "));
    	
    }
    
    public void bluemethod(View v)
    {
    	TextView t =(TextView) findViewById(R.id.textView1);
    	t.setTextColor(Color.parseColor("#FF0000 "));
    	
    }
    public void exitmethod(View v) {
        finish();
        System.exit(0);
    }
    
  
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        getMenuInflater().inflate(R.menu. main_activity1, menu);
        return true;
    }
    
}
