package com.example.navigateactivity;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Typeface;
import android.view.Menu;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity2_mail);
    }
    
    public void boldMethod(View v)
    {
    	TextView t =(TextView) findViewById(R.id.textView1);
    	t.setTypeface(t.getTypeface(), Typeface.BOLD);
    }
    
    public void italicMethod(View v)
    {
    	TextView t =(TextView) findViewById(R.id.textView1);
    	t.setTypeface(t.getTypeface(), Typeface.ITALIC);
    }
    
    
    public void exit(View v) {
        finish();
        System.exit(0);
    }
    
  
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        getMenuInflater().inflate(R.menu. main_activity1, menu);
        return true;
    }
    
}
